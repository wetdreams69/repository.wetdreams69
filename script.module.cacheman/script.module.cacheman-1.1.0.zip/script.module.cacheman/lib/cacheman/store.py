import fnmatch
import sqlite3
import threading
import time

import xbmc

from .connection  import ConnectionManager
from .serializer  import Serializer
from .constants   import DTYPE_JSON

__all__ = ['CacheStore']

class CacheStore:
    """
    Executes all cache read/write operations against SQLite.

    Responsibility: implement the Redis-like cache primitives (get, set,
    delete, ttl, expire, keys, clear, cleanup, info) and LRU eviction.
    It delegates connection management to ConnectionManager and
    data encoding to Serializer — it knows nothing about either.

    Performance design:
        - Lazy LRU:     last_accessed updates are buffered in memory and
                        flushed to disk every LRU_FLUSH_EVERY GETs (not per GET).
        - Throttled eviction: _enforce_limit() runs every EVICTION_CHECK_EVERY
                        SETs, not every single one.
        - GLOB pushdown: prefix patterns (e.g. 'channels:*') are evaluated by
                        SQLite directly, avoiding full table scan in Python.
    """

    __slots__ = (
        '_conn', '_serializer', 'max_entries',
        '_lru_lock', '_lru_buffer', '_lru_dirty',
        '_eviction_lock', '_set_count',
    )

                                                          
    _LRU_FLUSH_EVERY       = 50

                                                
    _EVICTION_CHECK_EVERY  = 20

                                                                        
                                                     
    _EVICTION_TARGET       = 0.90

    # Max entries in the in-memory LRU buffer before forced flush
    _MAX_LRU_BUFFER_SIZE   = 5000

    def __init__(
        self,
        conn_manager: ConnectionManager,
        serializer:   Serializer,
        max_entries:  int = 10000,
    ):
        self._conn       = conn_manager
        self._serializer = serializer
        self.max_entries = max_entries

                                                                                    
        self._lru_lock   = threading.Lock()
        self._lru_buffer = {}                                      
        self._lru_dirty  = 0                              

                                           
        self._eviction_lock  = threading.Lock()
        self._set_count      = 0

                                                                            
                         
                                                                            

    def get(self, key: str):
        """
        Return the cached value for key, or None if missing / expired.

        TTL is checked lazily (expired entries deleted on access).
        last_accessed is buffered — not written to disk on every GET.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            cursor.execute(
                'SELECT data, dtype, compressed, expires_at FROM cache WHERE key = ?',
                (key,),
            )
            row = cursor.fetchone()

            if not row:
                return None

                                     
            if row['expires_at'] is not None and time.time() >= row['expires_at']:
                cursor.execute('DELETE FROM cache WHERE key = ?', (key,))
                conn.commit()
                return None

                                                                   
            should_flush = self._touch_lru(key)
            if should_flush:
                self._flush_lru()

            dtype = row['dtype'] or DTYPE_JSON
            return self._serializer.deserialize(row['data'], bool(row['compressed']), dtype)

        except (sqlite3.Error, ValueError) as e:
            xbmc.log(f"[CacheMan] GET '{key}': {e}", xbmc.LOGERROR)
            return None

    @staticmethod
    def _validate_key(key: str):
        """Validate cache key — reject empty, too long, or keys with control chars."""
        if not key or not key.strip():
            raise ValueError("Cache key must be a non-empty string")
        if len(key) > 512:
            raise ValueError(f"Cache key too long ({len(key)} chars, max 512)")
        # Reject control characters (except tab which is unusual but allowed)
        for ch in key:
            if 0 <= ord(ch) <= 31 and ch not in ('\t',):
                raise ValueError(f"Cache key contains control character: {repr(ch)}")

    def set(self, key: str, value, ttl: int = None, dtype: str = DTYPE_JSON):
        """
        Store value under key.

        Args:
            key:   Cache key string.
            value: Value to store — type must match dtype.
            ttl:   Seconds until expiry. None = permanent.
            dtype: 'json' (default), 'str', or 'bytes'.

        Raises:
            ValueError: if key is empty, too long, or contains control characters.
        """
        self._validate_key(key)

        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            now        = int(time.time())
            expires_at = (now + ttl) if ttl is not None else None

            data_bytes, is_compressed = self._serializer.serialize(value, dtype)

            cursor.execute(
                '''
                INSERT OR REPLACE INTO cache
                    (key, data, dtype, compressed,
                     created_at, expires_at, last_accessed, data_size)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (key, data_bytes, dtype, int(is_compressed),
                 now, expires_at, now, len(data_bytes)),
            )
            conn.commit()

                                                            
            with self._eviction_lock:
                self._set_count += 1
                should_check = (self._set_count % self._EVICTION_CHECK_EVERY == 0)

            if should_check:
                self._enforce_limit()

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] SET '{key}': {e}", xbmc.LOGERROR)

    def delete(self, key: str):
        """Delete a key. No-op if the key doesn't exist."""
        conn = self._conn.get()
        try:
            conn.execute('DELETE FROM cache WHERE key = ?', (key,))
            conn.commit()
        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] DELETE '{key}': {e}", xbmc.LOGERROR)

    def __contains__(self, key: str) -> bool:
        """Support 'key in cache' syntax."""
        return self.exists(key)

    def get_many(self, keys: list) -> dict:
        """
        Return a dict of {key: value} for all existing keys in the list.
        Missing or expired keys are omitted from the result.
        """
        result = {}
        for key in keys:
            value = self.get(key)
            if value is not None:
                result[key] = value
        return result

    def set_many(self, mapping: dict, ttl: int = None, dtype: str = DTYPE_JSON):
        """
        Store multiple key-value pairs in a single transaction.

        Args:
            mapping: dict of {key: value}
            ttl:     Seconds until expiry. None = permanent.
            dtype:   Data type for ALL values in the mapping.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()
        now    = int(time.time())
        expires_at = (now + ttl) if ttl is not None else None

        try:
            rows = []
            for key, value in mapping.items():
                self._validate_key(key)
                data_bytes, is_compressed = self._serializer.serialize(value, dtype)
                rows.append((
                    key, data_bytes, dtype, int(is_compressed),
                    now, expires_at, now, len(data_bytes),
                ))

            cursor.executemany(
                '''
                INSERT OR REPLACE INTO cache
                    (key, data, dtype, compressed,
                     created_at, expires_at, last_accessed, data_size)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                rows,
            )
            conn.commit()
            xbmc.log(f"[CacheMan] SET_MANY: {len(rows)} keys", xbmc.LOGDEBUG)
        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] SET_MANY error: {e}", xbmc.LOGERROR)

    def increment(self, key: str, amount: int = 1, default: int = 0) -> int:
        """
        Atomically increment a numeric value stored under key.

        If the key does not exist, it is created with the default value
        before applying the increment. The value is stored as dtype='str'
        to avoid JSON float rounding issues.

        Returns:
            int: The new value after increment.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()
        now    = int(time.time())

        try:
            cursor.execute(
                'SELECT data FROM cache WHERE key = ? AND (expires_at IS NULL OR expires_at > ?)',
                (key, now),
            )
            row = cursor.fetchone()
            current = int(row['data'].decode('utf-8')) if row else default
            new_value = current + amount

            cursor.execute(
                '''
                INSERT OR REPLACE INTO cache
                    (key, data, dtype, compressed, created_at, expires_at, last_accessed, data_size)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (key, str(new_value).encode('utf-8'), 'str', 0, now, None, now, len(str(new_value))),
            )
            conn.commit()
            return new_value
        except (sqlite3.Error, ValueError, UnicodeDecodeError) as e:
            xbmc.log(f"[CacheMan] INCREMENT '{key}': {e}", xbmc.LOGERROR)
            return current if 'current' in dir() else default

    def decrement(self, key: str, amount: int = 1, default: int = 0) -> int:
        """Atomically decrement a numeric value. See increment()."""
        return self.increment(key, -amount, default)

    def touch(self, key: str) -> bool:
        """
        Update last_accessed timestamp without fetching the value.
        Returns True if the key existed, False otherwise.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()
        try:
            cursor.execute(
                'UPDATE cache SET last_accessed = ? WHERE key = ?',
                (int(time.time()), key),
            )
            conn.commit()
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] TOUCH '{key}': {e}", xbmc.LOGERROR)
            return False

    def rename(self, key: str, new_key: str) -> bool:
        """
        Rename a key. Returns True if the key was renamed, False if the
        original key does not exist or the new key already exists.
        """
        if key == new_key:
            return True
        self._validate_key(new_key)

        conn   = self._conn.get()
        cursor = conn.cursor()
        try:
            cursor.execute(
                'SELECT data, dtype, compressed, created_at, expires_at, last_accessed, data_size FROM cache WHERE key = ?',
                (key,),
            )
            row = cursor.fetchone()
            if not row:
                return False

            cursor.execute(
                'SELECT COUNT(1) FROM cache WHERE key = ?', (new_key,)
            )
            if cursor.fetchone()[0] > 0:
                return False

            cursor.execute(
                '''
                INSERT INTO cache (key, data, dtype, compressed, created_at, expires_at, last_accessed, data_size)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                (new_key, row['data'], row['dtype'], row['compressed'],
                 row['created_at'], row['expires_at'], row['last_accessed'], row['data_size']),
            )
            cursor.execute('DELETE FROM cache WHERE key = ?', (key,))
            conn.commit()
            return True
        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] RENAME '{key}' -> '{new_key}': {e}", xbmc.LOGERROR)
            return False

    def exists(self, key: str) -> bool:
        """
        Return True if key exists and has not expired.

        Uses a lightweight COUNT query instead of fetching the full value.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()
        try:
            cursor.execute(
                'SELECT COUNT(1) FROM cache WHERE key = ? AND (expires_at IS NULL OR expires_at > ?)',
                (key, time.time()),
            )
            return cursor.fetchone()[0] > 0
        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] EXISTS '{key}': {e}", xbmc.LOGERROR)
            return False

                                                                            
                        
                                                                            

    def ttl(self, key: str) -> int:
        """
        Return remaining TTL in seconds.

        Returns:
             >= 0  — seconds remaining
            -1     — key exists, no expiry (permanent)
            -2     — key does not exist
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            cursor.execute('SELECT expires_at FROM cache WHERE key = ?', (key,))
            row = cursor.fetchone()

            if not row:
                return -2

            if row['expires_at'] is None:
                return -1

            return max(0, int(row['expires_at'] - time.time()))

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] TTL '{key}': {e}", xbmc.LOGERROR)
            return -2

    def expire(self, key: str, ttl: int) -> bool:
        """
        Set or update the TTL of an existing key.

        Returns:
            True if the key existed and was updated, False otherwise.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            expires_at = int(time.time()) + ttl
            cursor.execute(
                'UPDATE cache SET expires_at = ? WHERE key = ?',
                (expires_at, key),
            )
            conn.commit()
            return cursor.rowcount > 0

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] EXPIRE '{key}': {e}", xbmc.LOGERROR)
            return False

    def persist(self, key: str) -> bool:
        """
        Remove the expiry from a key, making it permanent.

        Returns:
            True if the key existed and was updated, False otherwise.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            cursor.execute(
                'UPDATE cache SET expires_at = NULL WHERE key = ?',
                (key,),
            )
            conn.commit()
            return cursor.rowcount > 0

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] PERSIST '{key}': {e}", xbmc.LOGERROR)
            return False

                                                                            
                            
                                                                            

    def keys(self, pattern: str = '*') -> list:
        """
        Return all non-expired keys matching a glob pattern.

        Optimization: simple prefix patterns (e.g. 'channels:*') are
        pushed down to SQLite GLOB, avoiding a full table scan in Python.
        Complex patterns fall back to Python fnmatch.

        Args:
            pattern: Glob e.g. 'channels:*', '*:epg:*', '*'.

        Returns:
            List[str]
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            now = time.time()

                                                           
            if pattern == '*':
                cursor.execute(
                    'SELECT key FROM cache WHERE (expires_at IS NULL OR expires_at > ?)',
                    (now,),
                )
                return [row['key'] for row in cursor.fetchall()]

                                                                        
                                                                             
            if (pattern.endswith('*')
                    and '*' not in pattern[:-1]
                    and '?' not in pattern
                    and '[' not in pattern):
                cursor.execute(
                    '''
                    SELECT key FROM cache
                    WHERE key GLOB ?
                      AND (expires_at IS NULL OR expires_at > ?)
                    ''',
                    (pattern, now),
                )
                return [row['key'] for row in cursor.fetchall()]

                                                                                     
            cursor.execute(
                'SELECT key FROM cache WHERE (expires_at IS NULL OR expires_at > ?)',
                (now,),
            )
            return fnmatch.filter([row['key'] for row in cursor.fetchall()], pattern)

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] KEYS '{pattern}': {e}", xbmc.LOGERROR)
            return []

    def clear(self, pattern: str = None):
        """
        Delete all keys matching pattern, or flush everything if no pattern.

        Optimization: a single DELETE with GLOB pushdown instead of
        SELECT + DELETE (two round-trips).

        Args:
            pattern: Glob e.g. 'channels:*'. None = flush all.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            if pattern is None:
                cursor.execute('DELETE FROM cache')
                xbmc.log("[CacheMan] Flushed entire cache", xbmc.LOGDEBUG)
            else:
                # Single-pass delete with GLOB, including expired keys
                cursor.execute(
                    'DELETE FROM cache WHERE key GLOB ?',
                    (pattern,),
                )
                deleted = cursor.rowcount
                if deleted:
                    xbmc.log(
                        f"[CacheMan] Deleted {deleted} keys matching '{pattern}'",
                        xbmc.LOGDEBUG,
                    )
            conn.commit()

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] CLEAR '{pattern}': {e}", xbmc.LOGERROR)

                                                                            
                      
                                                                            

    def cleanup(self) -> int:
        """
        Delete all expired keys in one pass (active expiry sweep).

        Returns:
            Number of keys deleted.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            now = time.time()
            cursor.execute(
                'DELETE FROM cache WHERE expires_at IS NOT NULL AND expires_at <= ?',
                (now,),
            )
            deleted = cursor.rowcount
            conn.commit()

            if deleted:
                xbmc.log(f"[CacheMan] cleanup: removed {deleted} expired keys", xbmc.LOGDEBUG)

            return deleted

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] CLEANUP error: {e}", xbmc.LOGERROR)
            return 0

                                                                            
                    
                                                                            

    def info(self) -> dict:
        """
        Return a statistics snapshot of the cache.

        Returns:
            dict: {
                'total_keys':       int,
                'active_keys':      int,
                'expired_keys':     int,   -- not yet swept
                'total_size_bytes': int,
                'compressed_keys':  int,
                'by_dtype':         {'json': int, 'str': int, 'bytes': int},
                'lru_buffered':     int,   -- updates pending flush to disk
                'oldest_entry':     int or None,
                'newest_entry':     int or None,
            }
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            now = time.time()

            cursor.execute(
                '''
                SELECT
                    COUNT(*)                                                                     AS total,
                    SUM(CASE WHEN expires_at IS NULL OR expires_at > ?   THEN 1 ELSE 0 END)     AS active,
                    SUM(CASE WHEN expires_at IS NOT NULL AND expires_at <= ? THEN 1 ELSE 0 END) AS expired,
                    SUM(data_size)                                                               AS total_size,
                    SUM(CASE WHEN compressed = 1 THEN 1 ELSE 0 END)                             AS compressed,
                    MIN(created_at)                                                              AS oldest,
                    MAX(created_at)                                                              AS newest
                FROM cache
                ''',
                (now, now),
            )
            row = cursor.fetchone()

            cursor.execute('SELECT dtype, COUNT(*) AS n FROM cache GROUP BY dtype')
            by_dtype = {r['dtype']: r['n'] for r in cursor.fetchall()}

            with self._lru_lock:
                lru_buffered = self._lru_dirty

            return {
                'total_keys':       row['total']      or 0,
                'active_keys':      row['active']     or 0,
                'expired_keys':     row['expired']    or 0,
                'total_size_bytes': row['total_size'] or 0,
                'compressed_keys':  row['compressed'] or 0,
                'by_dtype':         by_dtype,
                'lru_buffered':     lru_buffered,
                'oldest_entry':     row['oldest'],
                'newest_entry':     row['newest'],
            }

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] INFO error: {e}", xbmc.LOGERROR)
            return None

                                                                            
                     
                                                                            

    def flush(self):
        """
        Force-flush any pending LRU updates to disk.
        Call this before closing the connection or on addon shutdown.
        """
        self._flush_lru()

    def vacuum(self):
        """Reclaim disk space from deleted rows (SQLite VACUUM)."""
        self._flush_lru()                                                   
        conn = self._conn.get()
        try:
            conn.execute('VACUUM')
            xbmc.log("[CacheMan] Database vacuumed", xbmc.LOGDEBUG)
        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] VACUUM error: {e}", xbmc.LOGERROR)

                                                                            
                                    
                                                                            

    def _touch_lru(self, key: str) -> bool:
        """
        Record a key access in the in-memory LRU buffer.

        If the buffer exceeds _MAX_LRU_BUFFER_SIZE, forces an immediate flush
        to prevent unbounded memory growth.

        Returns:
            True if the buffer has reached the flush threshold.
        """
        with self._lru_lock:
            self._lru_buffer[key] = int(time.time())
            self._lru_dirty += 1
            if self._lru_dirty >= self._MAX_LRU_BUFFER_SIZE:
                return True  # force flush immediately
            return self._lru_dirty >= self._LRU_FLUSH_EVERY

    def _flush_lru(self):
        """
        Write buffered last_accessed updates to disk in a single batch.

        Uses executemany() — one transaction for all pending updates
        instead of one commit per GET.
        """
        with self._lru_lock:
            if not self._lru_buffer:
                return
            snapshot         = list(self._lru_buffer.items())
            self._lru_buffer = {}
            self._lru_dirty  = 0

        try:
            conn = self._conn.get()
            conn.executemany(
                'UPDATE cache SET last_accessed = ? WHERE key = ?',
                [(ts, k) for k, ts in snapshot],
            )
            conn.commit()
            xbmc.log(f"[CacheMan] LRU flush: {len(snapshot)} keys", xbmc.LOGDEBUG)

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] LRU flush error: {e}", xbmc.LOGERROR)

                                                                            
                                 
                                                                            

    def _enforce_limit(self):
        """
        Evict LRU keys when total exceeds max_entries.

        Evicts down to _EVICTION_TARGET × max_entries to avoid running
        again on every subsequent SET near the limit.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        try:
            cursor.execute('SELECT COUNT(*) AS n FROM cache')
            count = cursor.fetchone()['n']

            if count <= self.max_entries:
                return

                                                                    
            target = int(self.max_entries * self._EVICTION_TARGET)
            evict  = count - target

            cursor.execute(
                '''
                DELETE FROM cache WHERE key IN (
                    SELECT key FROM cache
                    ORDER BY last_accessed ASC
                    LIMIT ?
                )
                ''',
                (evict,),
            )
            conn.commit()
            xbmc.log(
                f"[CacheMan] Evicted {evict} LRU keys (target: {target})",
                xbmc.LOGDEBUG,
            )

        except sqlite3.Error as e:
            xbmc.log(f"[CacheMan] LRU eviction error: {e}", xbmc.LOGERROR)
