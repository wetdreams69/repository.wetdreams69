import os
import sqlite3
import threading

import xbmc
from xbmcvfs import translatePath

__all__ = ['ConnectionManager']

class ConnectionManager:
    """
    Manages thread-local SQLite connections and path resolution.

    Responsibility: know *where* the database lives and *how* to open
    a connection to it — one per thread, created on demand.

    It has no knowledge of the schema, serialization, or cache logic.
    """

    __slots__ = ('db_name', '_local', '_all_connections', '_conn_lock')

    def __init__(self, db_name='cache.db'):
        """
        Args:
            db_name: SQLite filename. Stored inside the Kodi addon profile dir.
        """
        self.db_name = db_name
        self._local  = threading.local()
        self._all_connections: list[sqlite3.Connection] = []
        self._conn_lock = threading.Lock()

                                                                            
                    
                                                                            

    def get(self) -> sqlite3.Connection:
        """
        Return the thread-local SQLite connection, creating it if needed.

        Returns:
            sqlite3.Connection with row_factory set to sqlite3.Row.
        """
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            conn = sqlite3.connect(
                self._resolve_path(),
                check_same_thread=False,
                timeout=10.0,
            )
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
            with self._conn_lock:
                self._all_connections.append(conn)

        return self._local.conn

    def close(self):
        """Close ALL connections across all threads (call on addon shutdown)."""
        with self._conn_lock:
            connections = list(self._all_connections)
            self._all_connections.clear()

        for conn in connections:
            try:
                conn.close()
            except sqlite3.Error as e:
                xbmc.log(f"[CacheMan] ConnectionManager.close: {e}", xbmc.LOGERROR)

        # Also clear the current thread's reference
        if hasattr(self._local, 'conn'):
            self._local.conn = None

                                                                            
                  
                                                                            

    def _resolve_path(self) -> str:
        """
        Resolve the full filesystem path for the SQLite file.

        Falls back to a temp directory when called outside a Kodi context
        (e.g. unit tests).
        """
        try:
            import xbmcaddon
            addon       = xbmcaddon.Addon()
            profile_dir = translatePath(addon.getAddonInfo('profile'))
        except RuntimeError:
            profile_dir = translatePath('special://temp/cacheman/')

        os.makedirs(profile_dir, exist_ok=True)
        return os.path.join(profile_dir, self.db_name)
