import sqlite3

import xbmc

from .connection import ConnectionManager

__all__ = ['SchemaManager']

class SchemaManager:
    """
    Manages the SQLite schema lifecycle: table creation and migrations.

    Responsibility: ensure the database structure is correct before any
    read/write operation. It has no knowledge of serialization or cache logic.
    """

    __slots__ = ('_conn',)

    def __init__(self, conn_manager: ConnectionManager):
        self._conn = conn_manager

    def initialize(self):
        """
        Create the cache table and indexes if they don't exist,
        then apply any pending migrations.
        """
        conn   = self._conn.get()
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache (
                key           TEXT PRIMARY KEY,
                data          BLOB    NOT NULL,
                dtype         TEXT    DEFAULT 'json',
                compressed    INTEGER DEFAULT 0,
                created_at    INTEGER NOT NULL,
                expires_at    INTEGER,
                last_accessed INTEGER NOT NULL,
                data_size     INTEGER DEFAULT 0
            )
        ''')

        # PRAGMAs must be set outside any transaction — do them before _migrate
        conn.execute("PRAGMA journal_mode=WAL")
                                                                                    
        conn.execute("PRAGMA synchronous=NORMAL")
                                                                                   
        conn.execute("PRAGMA cache_size=-8000")

        # Auto-checkpoint WAL every 1000 pages to prevent unbounded WAL growth
        conn.execute("PRAGMA wal_autocheckpoint=1000")

        self._migrate(cursor)

        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_expires_at
            ON cache(expires_at)
        ''')

        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_last_accessed
            ON cache(last_accessed)
        ''')

        conn.commit()

                                                                            
                  
                                                                            

    def _migrate(self, cursor):
        """Apply incremental schema migrations (additive only)."""
        # Track schema version for future migrations
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS _schema_version (
                version INTEGER PRIMARY KEY
            )
        ''')
        cursor.execute('SELECT MAX(version) AS v FROM _schema_version')
        row = cursor.fetchone()
        current_version = row['v'] if row and row['v'] is not None else 0

        if current_version < 1:
            cursor.execute("PRAGMA table_info(cache)")
            columns = {r['name'] for r in cursor.fetchall()}
            if 'dtype' not in columns:
                cursor.execute("ALTER TABLE cache ADD COLUMN dtype TEXT DEFAULT 'json'")
                xbmc.log("[CacheMan] Migration applied: added 'dtype' column", xbmc.LOGDEBUG)
            cursor.execute('INSERT INTO _schema_version (version) VALUES (1)')
            xbmc.log("[CacheMan] Schema migrated to version 1", xbmc.LOGDEBUG)
